class HomsController < ApplicationController
  def top
  end
end
