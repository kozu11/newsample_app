# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '681a6a1b6ea90db30ab14659746ae45b09fbc4974d9389b6d210c712ffe252c45f7e1f9de3e7006ea945e1e268ae195c557dfd47cf76cd8924c9fd4b6e51b0f2'